# SHANKARA HEALING MUSIC — Starter v0.2

Starter Flutter untuk aplikasi musik dan galeri foto premium Shankara.

## Status fitur
- Tampilan dasar aplikasi: tersedia.
- Daftar foto dari Supabase: tersedia.
- Unggah foto oleh akun admin: tersedia setelah konfigurasi Supabase.
- Harga per foto: metadata harga tersedia.
- Login/daftar akun: dasar tersedia.
- Pembayaran dan unduhan file asli: BELUM diaktifkan.
- Pemutar musik/background audio: tahap berikutnya.

## Persiapan Supabase
1. Buat project di https://supabase.com.
2. Jalankan `supabase/schema.sql` di SQL Editor.
3. Buat bucket `photo-previews` dan atur sebagai PUBLIC. Isi bucket ini hanya gambar pratinjau yang sudah diberi watermark, bukan file asli.
4. Buat bucket `photo-originals` dan atur sebagai PRIVATE.
5. Daftarkan akun pemilik melalui aplikasi.
6. Buka Authentication > Users, salin UUID akun pemilik.
7. Jalankan SQL: `update public.profiles set role = 'admin' where id = 'UUID-AKUN-PEMILIK';`
8. Salin Project URL dan anon/public key dari Project Settings > API.

## Menjalankan proyek
Pastikan Flutter dan Android toolchain sudah terpasang di komputer.
Jalankan:
```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=ANON_KEY
```

## Keamanan dan pembayaran — wajib sebelum rilis
- Jangan simpan service-role key di aplikasi.
- Jangan unggah file resolusi asli ke bucket publik.
- Tambahkan watermark pada gambar pratinjau sebelum mengunggah.
- File asli harus tetap di bucket private.
- Pembelian harus dibuat dan diverifikasi di server melalui penyedia pembayaran.
- Setelah webhook pembayaran tervalidasi, server mencatat kepemilikan foto dan memberi signed URL berumur pendek untuk unduhan.
- Jangan membuka akses file asli hanya berdasarkan status dari aplikasi.
- Lengkapi kebijakan RLS untuk tabel order/purchases dan Storage sebelum produksi.
- Integrasi pembayaran harus mengikuti aturan Google Play dan Apple App Store yang berlaku untuk konten digital.

## Catatan
Proyek ini adalah starter pengembangan, bukan APK siap pasang dan bukan sistem pembayaran produksi.
